#ifndef WORD_COUNTER_H
#define WORD_COUNTER_H

#include <stdio.h>

int word_counter(FILE *fp);

#endif