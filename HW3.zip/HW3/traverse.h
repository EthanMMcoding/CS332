#ifndef TRAVERSE_H
#define TRAVERSE_H

#include <stdio.h>
#include "file_struct.h"

size_t traverse(const char *arg, file **file_arr);

#endif