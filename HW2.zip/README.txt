Homework02 README.txt

Name: Ethan Martignoni
BlazerID: Ethanmm
Project #: Homework #2

To compile:
  Using Makefile: make
  Without Makefile:
    gcc -Wall -g -o hw2 Homework02.case

To run:
  Using Makefile: make run ARGS="..."
  Without Makefile: ./hw2 ...

Clean up:
  Using Makefile: make clean
  Without Makefile: rm -f hw2
